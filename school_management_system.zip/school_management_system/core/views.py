from django.shortcuts import render, get_object_or_404, redirect
from django.contrib import messages
from django.http import JsonResponse
from django.core.paginator import Paginator
from django.db.models import Q, Count, Avg
from django.utils import timezone
from datetime import datetime, timedelta
import json
import logging

logger = logging.getLogger(__name__)
from django.contrib.auth import login
from .forms import CustomUserCreationForm, ClassForm, StudentForm, ClassSubjectForm
from .forms import TeacherForm, AssignSubjectToTeacherForm # Import TeacherForm and AssignSubjectToTeacherForm

from .models import Student, Teacher, Class, Subject, ClassSubject, StudentClass, Attendance, Grade

def dashboard(request):
    """Main dashboard view with statistics"""
    context = {
        'total_students': Student.objects.filter(is_active=True).count(),
        'total_teachers': Teacher.objects.filter(is_active=True).count(),
        'total_classes': Class.objects.filter(is_active=True).count(),
        'total_subjects': Subject.objects.filter(is_active=True).count(),
    }
    
    # Recent activities
    recent_attendance = Attendance.objects.select_related('student', 'class_subject__subject').order_by('-recorded_at')[:5]
    recent_grades = Grade.objects.select_related('student', 'class_subject__subject').order_by('-graded_at')[:5]
    
    context.update({
        'recent_attendance': recent_attendance,
        'recent_grades': recent_grades,
    })
    
    return render(request, 'core/dashboard.html', context)

def register(request):
    """User registration view"""
    if request.method == 'POST':
        form = CustomUserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            messages.success(request, 'Registration successful!')
            return redirect('core:dashboard')
        else:
            messages.error(request, 'Registration failed. Please correct the errors below.')
    else:
        form = CustomUserCreationForm()
    return render(request, 'registration/register.html', {'form': form})

# Student Views
def student_list(request):
    """List all students with search and pagination"""
    students = Student.objects.filter(is_active=True)
    
    # Search functionality
    search_query = request.GET.get('search', '')
    if search_query:
        students = students.filter(
            Q(first_name__icontains=search_query) |
            Q(last_name__icontains=search_query) |
            Q(student_id__icontains=search_query) |
            Q(email__icontains=search_query)
        )
    
    # Pagination
    paginator = Paginator(students, 10)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    
    context = {
        'page_obj': page_obj,
        'search_query': search_query,
    }
    return render(request, 'core/student_list.html', context)

def student_detail(request, student_id):
    """Show detailed information about a student"""
    student = get_object_or_404(Student, id=student_id)
    
    # Get student's enrolled classes
    enrolled_classes = StudentClass.objects.filter(student=student, is_active=True)
    
    # Get recent attendance
    recent_attendance = Attendance.objects.filter(student=student).order_by('-date')[:10]
    
    # Get recent grades
    recent_grades = Grade.objects.filter(student=student).order_by('-graded_at')[:10]
    
    context = {
        'student': student,
        'enrolled_classes': enrolled_classes,
        'recent_attendance': recent_attendance,
        'recent_grades': recent_grades,
    }
    return render(request, 'core/student_detail.html', context)

def student_create(request):
    """Create a new student"""
    if request.method == 'POST':
        form = StudentForm(request.POST, request.FILES)
        if form.is_valid():
            student = form.save()
            messages.success(request, f'Student {student.full_name} created successfully!')
            return redirect('core:student_detail', student_id=student.id)
        else:
            messages.error(request, 'Error creating student. Please correct the errors below.')
    else:
        form = StudentForm()
    return render(request, 'core/student_form.html', {'form': form})

def student_update(request, student_id):
    """Update student information"""
    student = get_object_or_404(Student, id=student_id)
    
    if request.method == 'POST':
        form = StudentForm(request.POST, request.FILES, instance=student)
        if form.is_valid():
            form.save()
            messages.success(request, f'Student {student.full_name} updated successfully!')
            return redirect('core:student_detail', student_id=student.id)
        else:
            messages.error(request, 'Error updating student. Please correct the errors below.')
    else:
        form = StudentForm(instance=student)
    
    context = {'form': form, 'student': student}
    return render(request, 'core/student_form.html', context)

def student_delete(request, student_id):
    """Delete a student (soft delete)"""
    student = get_object_or_404(Student, id=student_id)
    
    if request.method == 'POST':
        student.is_active = False
        student.save()
        messages.success(request, f'Student {student.full_name} deleted successfully!')
        return redirect('core:student_list')
    
    context = {'student': student}
    return render(request, 'core/student_confirm_delete.html', context)

# Teacher Views
def teacher_list(request):
    """List all teachers with search and pagination"""
    teachers = Teacher.objects.filter(is_active=True)
    
    # Search functionality
    search_query = request.GET.get('search', '')
    if search_query:
        teachers = teachers.filter(
            Q(first_name__icontains=search_query) |
            Q(last_name__icontains=search_query) |
            Q(teacher_id__icontains=search_query) |
            Q(email__icontains=search_query)
        )
    
    # Pagination
    paginator = Paginator(teachers, 10)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    
    context = {
        'page_obj': page_obj,
        'search_query': search_query,
    }
    return render(request, 'core/teacher_list.html', context)

def teacher_detail(request, teacher_id):
    """Show detailed information about a teacher"""
    teacher = get_object_or_404(Teacher, id=teacher_id)
    
    # Get teacher's subjects
    teaching_subjects = ClassSubject.objects.filter(teacher=teacher)
    
    context = {
        'teacher': teacher,
        'teaching_subjects': teaching_subjects,
    }
    return render(request, 'core/teacher_detail.html', context)

def teacher_create(request):
    """Create a new teacher"""
    if request.method == 'POST':
        form = TeacherForm(request.POST, request.FILES)
        if form.is_valid():
            teacher = form.save()
            messages.success(request, f'Teacher {teacher.full_name} created successfully!')
            return redirect('core:teacher_detail', teacher_id=teacher.id)
        else:
            messages.error(request, 'Error creating teacher. Please correct the errors below.')
    else:
        form = TeacherForm()
    return render(request, 'core/teacher_form.html', {'form': form})

def teacher_update(request, teacher_id):
    """Update teacher information"""
    teacher = get_object_or_404(Teacher, id=teacher_id)
    
    if request.method == 'POST':
        form = TeacherForm(request.POST, request.FILES, instance=teacher)
        if form.is_valid():
            form.save()
            messages.success(request, f'Teacher {teacher.full_name} updated successfully!')
            return redirect('core:teacher_detail', teacher_id=teacher.id)
        else:
            messages.error(request, 'Error updating teacher. Please correct the errors below.')
    else:
        form = TeacherForm(instance=teacher)
    
    context = {'form': form, 'teacher': teacher}
    return render(request, 'core/teacher_form.html', context)

def teacher_delete(request, teacher_id):
    """Delete a teacher (soft delete)"""
    teacher = get_object_or_404(Teacher, id=teacher_id)
    
    if request.method == 'POST':
        teacher.is_active = False
        teacher.save()
        messages.success(request, f'Teacher {teacher.full_name} deleted successfully!')
        return redirect('core:teacher_list')
    
    context = {'teacher': teacher}
    return render(request, 'core/teacher_confirm_delete.html', context)

def teacher_assign_subject(request, teacher_id):
    """Assign a subject to a teacher"""
    teacher = get_object_or_404(Teacher, id=teacher_id)
    
    if request.method == 'POST':
        form = AssignSubjectToTeacherForm(request.POST)
        if form.is_valid():
            class_subject = form.save(commit=False)
            class_subject.teacher = teacher
            class_subject.save()
            messages.success(request, f'Subject {class_subject.subject.name} assigned to {teacher.full_name} successfully!')
            return redirect('core:teacher_detail', teacher_id=teacher.id)
        else:
            messages.error(request, 'Error assigning subject. Please correct the errors below.')
    else:
        form = AssignSubjectToTeacherForm()
    
    context = {
        'form': form,
        'teacher': teacher,
        'title': f'Assign Subject to {teacher.full_name}',
        'is_create': True,
    }
    return render(request, 'core/teacher_assign_subject_form.html', context)

def teacher_subject_update(request, teacher_id, pk):
    """Update a teacher's assigned subject"""
    teacher = get_object_or_404(Teacher, id=teacher_id)
    class_subject = get_object_or_404(ClassSubject, teacher=teacher, pk=pk)
    
    if request.method == 'POST':
        form = AssignSubjectToTeacherForm(request.POST, instance=class_subject)
        if form.is_valid():
            form.save()
            messages.success(request, f'Assigned subject {class_subject.subject.name} for {teacher.full_name} updated successfully!')
            return redirect('core:teacher_detail', teacher_id=teacher.id)
        else:
            messages.error(request, 'Error updating assigned subject. Please correct the errors below.')
    else:
        form = AssignSubjectToTeacherForm(instance=class_subject)
        
    context = {
        'form': form,
        'teacher': teacher,
        'class_subject': class_subject,
        'title': f'Update Subject for {teacher.full_name}',
        'is_create': False,
    }
    return render(request, 'core/teacher_assign_subject_form.html', context)

def teacher_subject_delete(request, teacher_id, pk):
    """Delete a teacher's assigned subject"""
    teacher = get_object_or_404(Teacher, id=teacher_id)
    class_subject = get_object_or_404(ClassSubject, teacher=teacher, pk=pk)
    
    if request.method == 'POST':
        class_subject.delete()
        messages.success(request, f'Subject {class_subject.subject.name} unassigned from {teacher.full_name} successfully!')
        return redirect('core:teacher_detail', teacher_id=teacher.id)
    
    context = {
        'teacher': teacher,
        'class_subject': class_subject,
    }
    return render(request, 'core/teacher_subject_confirm_delete.html', context)

# Class Subject Views
def class_subject_create(request, class_id):
    class_obj = get_object_or_404(Class, id=class_id)
    if request.method == 'POST':
        form = ClassSubjectForm(request.POST)
        if form.is_valid():
            class_subject = form.save(commit=False)
            class_subject.class_obj = class_obj
            class_subject.save()
            messages.success(request, 'Class subject added successfully!')
            return redirect('core:class_detail', class_id=class_id)
        else:
            messages.error(request, 'Error adding class subject. Please correct the errors below.')
    else:
        form = ClassSubjectForm()
    
    context = {
        'form': form,
        'class_obj': class_obj,
        'title': 'Add Class Subject',
        'is_create': True,
    }
    return render(request, 'core/class_subject_form.html', context)

def class_subject_update(request, class_id, pk):
    class_obj = get_object_or_404(Class, id=class_id)
    class_subject = get_object_or_404(ClassSubject, class_obj=class_obj, pk=pk)
    
    if request.method == 'POST':
        form = ClassSubjectForm(request.POST, instance=class_subject)
        if form.is_valid():
            form.save()
            messages.success(request, 'Class subject updated successfully!')
            return redirect('core:class_detail', class_id=class_id)
        else:
            messages.error(request, 'Error updating class subject. Please correct the errors below.')
    else:
        form = ClassSubjectForm(instance=class_subject)
        
    context = {
        'form': form,
        'class_obj': class_obj,
        'class_subject': class_subject,
        'title': 'Update Class Subject',
        'is_create': False,
    }
    return render(request, 'core/class_subject_form.html', context)

def class_subject_delete(request, class_id, pk):
    class_obj = get_object_or_404(Class, id=class_id)
    class_subject = get_object_or_404(ClassSubject, class_obj=class_obj, pk=pk)
    
    if request.method == 'POST':
        class_subject.delete()
        messages.success(request, 'Class subject deleted successfully!')
        return redirect('core:class_detail', class_id=class_id)
    
    context = {
        'class_obj': class_obj,
        'class_subject': class_subject,
    }
    return render(request, 'core/class_subject_confirm_delete.html', context)

# Class Views
def class_list(request):
    """List all classes"""
    classes = Class.objects.filter(is_active=True)
    
    # Search functionality
    search_query = request.GET.get('search', '')
    if search_query:
        classes = classes.filter(
            Q(name__icontains=search_query) |
            Q(description__icontains=search_query) |
            Q(academic_year__icontains=search_query)
        )
    
    # Pagination
    paginator = Paginator(classes, 10)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    
    context = {
        'page_obj': page_obj,
        'search_query': search_query,
    }
    return render(request, 'core/class_list.html', context)

def class_detail(request, class_id):
    """Show detailed information about a class"""
    class_obj = get_object_or_404(Class, id=class_id)
    
    # Get enrolled students
    enrolled_students = StudentClass.objects.filter(class_obj=class_obj, is_active=True)
    
    # Get class subjects
    class_subjects = ClassSubject.objects.filter(class_obj=class_obj)

    # Calculate available seats
    available_seats = class_obj.capacity - enrolled_students.count()
    
    context = {
        'class_obj': class_obj,
        'enrolled_students': enrolled_students,
        'class_subjects': class_subjects,
        'available_seats': available_seats,
    }
    return render(request, 'core/class_detail.html', context)

def class_create(request):
    """Create a new class"""
    if request.method == 'POST':
        form = ClassForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Class created successfully!')
            return redirect('core:class_list')
        else:
            messages.error(request, 'Error creating class. Please correct the errors below.')
    else:
        form = ClassForm()
    return render(request, 'core/class_form.html', {'form': form})

def class_update(request, pk):
    """Update class information"""
    class_obj = get_object_or_404(Class, pk=pk)
    if request.method == 'POST':
        form = ClassForm(request.POST, instance=class_obj)
        if form.is_valid():
            form.save()
            messages.success(request, f'Class {class_obj.name} updated successfully!')
            return redirect('core:class_list')
        else:
            messages.error(request, 'Error updating class. Please correct the errors below.')
    else:
        form = ClassForm(instance=class_obj)
    return render(request, 'core/class_form.html', {'form': form, 'class_obj': class_obj})

def class_delete(request, pk):
    """Delete a class (soft delete)"""
    class_obj = get_object_or_404(Class, pk=pk)
    
    if request.method == 'POST':
        class_obj.is_active = False
        class_obj.save()
        messages.success(request, f'Class {class_obj.name} deleted successfully!')
        return redirect('core:class_list')
    
    context = {'class_obj': class_obj}
    return render(request, 'core/class_confirm_delete.html', context)

def enroll_students_in_class(request, class_id):
    """Enroll students into a specific class"""
    class_obj = get_object_or_404(Class, id=class_id)
    
    if request.method == 'POST':
        student_ids = request.POST.getlist('students')
        if not student_ids:
            messages.error(request, 'No students selected for enrollment.')
            return redirect('core:enroll_students_in_class', class_id=class_id)
            
        enrolled_count = 0
        for student_id in student_ids:
            student = get_object_or_404(Student, id=student_id)
            # Check if student is already enrolled to prevent duplicates
            if not StudentClass.objects.filter(student=student, class_obj=class_obj).exists():
                StudentClass.objects.create(student=student, class_obj=class_obj)
                enrolled_count += 1
        
        if enrolled_count > 0:
            messages.success(request, f'{enrolled_count} student(s) enrolled successfully into {class_obj.name}!')
        else:
            messages.info(request, 'No new students were enrolled.')
            
        return redirect('core:class_detail', class_id=class_id)
    
    # For GET request, display students not yet in this class
    enrolled_students_ids = StudentClass.objects.filter(class_obj=class_obj).values_list('student__id', flat=True)
    available_students = Student.objects.filter(is_active=True).exclude(id__in=enrolled_students_ids)
    
    context = {
        'class_obj': class_obj,
        'available_students': available_students,
    }
    return render(request, 'core/enroll_students_in_class.html', context)

def student_class_update(request, class_id, pk):
    """Update a student's enrollment status in a class"""
    student_class = get_object_or_404(StudentClass, class_obj_id=class_id, pk=pk)
    
    if request.method == 'POST':
        is_active = request.POST.get('is_active') == 'on'  # Checkbox value
        student_class.is_active = is_active
        student_class.save()
        messages.success(request, f'Enrollment for {student_class.student.full_name} in {student_class.class_obj.name} updated successfully!')
        return redirect('core:class_detail', class_id=class_id)
    
    context = {
        'student_class': student_class,
        'class_obj': student_class.class_obj,
    }
    return render(request, 'core/student_class_form.html', context)

def student_class_delete(request, class_id, pk):
    """Deactivate a student's enrollment in a class (soft delete)"""
    student_class = get_object_or_404(StudentClass, class_obj_id=class_id, pk=pk)
    
    if request.method == 'POST':
        student_class.is_active = False
        student_class.save()
        messages.success(request, f'Enrollment for {student_class.student.full_name} in {student_class.class_obj.name} deactivated successfully!')
        return redirect('core:class_detail', class_id=class_id)
    
    context = {
        'student_class': student_class,
        'class_obj': student_class.class_obj,
    }
    return render(request, 'core/student_class_confirm_delete.html', context)

# Attendance Views
def attendance_list(request):
    """List attendance records with filtering"""
    attendance_records = Attendance.objects.select_related('student', 'class_subject__subject', 'class_subject__class_obj')
    
    # Filter by date
    date_filter = request.GET.get('date', '')
    if date_filter:
        attendance_records = attendance_records.filter(date=date_filter)
    
    # Filter by class
    class_filter = request.GET.get('class', '')
    if class_filter:
        attendance_records = attendance_records.filter(class_subject__class_obj_id=class_filter)
    
    # Filter by status
    status_filter = request.GET.get('status', '')
    if status_filter:
        attendance_records = attendance_records.filter(status=status_filter)
    
    # Pagination
    paginator = Paginator(attendance_records, 20)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    
    # Get available classes for filter
    classes = Class.objects.filter(is_active=True)
    
    context = {
        'page_obj': page_obj,
        'classes': classes,
        'date_filter': date_filter,
        'class_filter': class_filter,
        'status_filter': status_filter,
    }
    return render(request, 'core/attendance_list.html', context)

def attendance_create(request):
    """Create attendance records"""
    if request.method == 'POST':
        try:
            # Handle bulk attendance creation
            class_subject_id = request.POST.get('class_subject')
            date = request.POST.get('date')
            attendance_data = json.loads(request.POST.get('attendance_data', '[]'))
            
            class_subject = get_object_or_404(ClassSubject, id=class_subject_id)
            
            # Create attendance records
            for record in attendance_data:
                student_id = record.get('student_id')
                status = record.get('status')
                remarks = record.get('remarks', '')
                
                if student_id and status:
                    Attendance.objects.create(
                        student_id=student_id,
                        class_subject=class_subject,
                        date=date,
                        status=status,
                        remarks=remarks,
                        recorded_by=None  # TODO: Add teacher reference when authentication is implemented
                    )
            
            messages.success(request, 'Attendance recorded successfully!')
            return redirect('core:attendance_list')
            
        except Exception as e:
            messages.error(request, f'Error recording attendance: {str(e)}')
    
    # Get available class subjects
    class_subjects = ClassSubject.objects.select_related('class_obj', 'subject')
    
    context = {
        'class_subjects': class_subjects,
    }
    return render(request, 'core/attendance_form.html', context)

def attendance_update(request, pk):
    """Update an existing attendance record"""
    try:
        attendance = get_object_or_404(Attendance.objects.select_related('student', 'class_subject__class_obj', 'class_subject__subject'), pk=pk)
    except Attendance.student.RelatedObjectDoesNotExist:
        logger.error(f"RelatedObjectDoesNotExist for Attendance {pk} - missing student")
        messages.error(request, 'The student associated with this attendance record could not be found.')
        return redirect('core:attendance_list')
    except Attendance.class_subject.RelatedObjectDoesNotExist:
        logger.error(f"RelatedObjectDoesNotExist for Attendance {pk} - missing class subject")
        messages.error(request, 'The class subject associated with this attendance record could not be found.')
        return redirect('core:attendance_list')

    
    if request.method == 'POST':
        try:
            attendance.status = request.POST.get('status')
            attendance.remarks = request.POST.get('remarks', '')
            attendance.date = request.POST.get('date')
            attendance.class_subject_id = request.POST.get('class_subject')
            attendance.student_id = request.POST.get('student') # This should not be changed via update
            attendance.save()
            messages.success(request, 'Attendance record updated successfully!')
            return redirect('core:attendance_list')
        except Exception as e:
            messages.error(request, f'Error updating attendance: {str(e)}')
    
    class_subjects = ClassSubject.objects.select_related('class_obj', 'subject')
    students_in_class = StudentClass.objects.filter(class_obj=attendance.class_subject.class_obj).select_related('student')
    
    context = {
        'attendance': attendance,
        'class_subjects': class_subjects,
        'students_in_class': students_in_class,
        'current_class_id': attendance.class_subject.class_obj.id,
        'current_class_subject_id': attendance.class_subject.id,
        'current_student_id': attendance.student.id if attendance.student else None,
    }
    return render(request, 'core/attendance_update.html', context)

def attendance_statistics(request):
    """Display attendance statistics"""
    total_records = Attendance.objects.count()
    
    # Overall statistics
    overall_stats = Attendance.objects.values('status').annotate(count=Count('status'))
    overall_stats_dict = {item['status']: item['count'] for item in overall_stats}
    
    # Statistics by class
    class_stats = Class.objects.filter(is_active=True).annotate(
        total_attendance=Count('classsubject__attendance_records'),
        present_count=Count('classsubject__attendance_records', filter=Q(classsubject__attendance_records__status='present')),
        absent_count=Count('classsubject__attendance_records', filter=Q(classsubject__attendance_records__status='absent')),
        late_count=Count('classsubject__attendance_records', filter=Q(classsubject__attendance_records__status='late')),
        excused_count=Count('classsubject__attendance_records', filter=Q(classsubject__attendance_records__status='excused'))
    )
    
    # Statistics by student
    student_stats = Student.objects.filter(is_active=True).annotate(
        total_attendance=Count('attendance_records'),
        present_count=Count('attendance_records', filter=Q(attendance_records__status='present')),
        absent_count=Count('attendance_records', filter=Q(attendance_records__status='absent')),
        late_count=Count('attendance_records', filter=Q(attendance_records__status='late')),
        excused_count=Count('attendance_records', filter=Q(attendance_records__status='excused'))
    )
    
    context = {
        'total_records': total_records,
        'overall_stats': overall_stats_dict,
        'class_stats': class_stats,
        'student_stats': student_stats,
    }
    return render(request, 'core/attendance_statistics.html', context)

# Grade Views
def grade_list(request):
    """List grade records with filtering"""
    grades = Grade.objects.select_related('student', 'class_subject__subject', 'class_subject__class_obj')
    
    # Filter by class
    class_filter = request.GET.get('class', '')
    if class_filter:
        grades = grades.filter(class_subject__class_obj_id=class_filter)
    
    # Filter by subject
    subject_filter = request.GET.get('subject', '')
    if subject_filter:
        grades = grades.filter(class_subject__subject_id=subject_filter)
    
    # Filter by grade
    grade_filter = request.GET.get('grade', '')
    if grade_filter:
        grades = grades.filter(grade=grade_filter)
    
    # Pagination
    paginator = Paginator(grades, 20)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    
    # Get available classes and subjects for filter
    classes = Class.objects.filter(is_active=True)
    subjects = Subject.objects.filter(is_active=True)
    grades_list = ['A+', 'A', 'A-', 'B+', 'B', 'B-', 'C+', 'C', 'C-', 'D+', 'D', 'F']
    
    context = {
        'page_obj': page_obj,
        'classes': classes,
        'subjects': subjects,
        'class_filter': class_filter,
        'subject_filter': subject_filter,
        'grade_filter': grade_filter,
        'grades_list': grades_list,
    }
    return render(request, 'core/grade_list.html', context)

def grade_create(request):
    """Create grade records"""
    if request.method == 'POST':
        try:
            # Handle bulk grade creation
            class_subject_id = request.POST.get('class_subject')
            assignment_name = request.POST.get('assignment_name')
            max_score = request.POST.get('max_score', 100)
            grades_data = json.loads(request.POST.get('grades_data', '[]'))
            
            class_subject = get_object_or_404(ClassSubject, id=class_subject_id)
            
            # Create grade records
            for record in grades_data:
                student_id = record.get('student_id')
                score = record.get('score')
                grade = record.get('grade')
                remarks = record.get('remarks', '')
                
                if student_id and score and grade:
                    Grade.objects.create(
                        student_id=student_id,
                        class_subject=class_subject,
                        assignment_name=assignment_name,
                        grade=grade,
                        score=score,
                        max_score=max_score,
                        remarks=remarks,
                        graded_by=None  # TODO: Add teacher reference when authentication is implemented
                    )
            
            messages.success(request, 'Grades recorded successfully!')
            return redirect('core:grade_list')
            
        except Exception as e:
            messages.error(request, f'Error recording grades: {str(e)}')
    
    # Get available class subjects
    class_subjects = ClassSubject.objects.select_related('class_obj', 'subject')
    
    context = {
        'class_subjects': class_subjects,
    }
    return render(request, 'core/grade_form.html', context)

# API Views for AJAX
def get_students_by_class(request):
    """Get students enrolled in a specific class for AJAX requests"""
    class_id = request.GET.get('class_id')
    if class_id:
        students = StudentClass.objects.filter(
            class_obj_id=class_id, 
            is_active=True
        ).select_related('student')
        
        student_list = []
        for student_class in students:
            student_list.append({
                'id': student_class.student.id,
                'name': student_class.student.full_name,
                'student_id': student_class.student.student_id,
            })
        
        return JsonResponse({'students': student_list})
    
    return JsonResponse({'students': []})

def get_class_subjects(request):
    """Get subjects for a specific class for AJAX requests"""
    class_id = request.GET.get('class_id')
    if class_id:
        subjects = ClassSubject.objects.filter(
            class_obj_id=class_id
        ).select_related('subject', 'teacher')
        
        subject_list = []
        for class_subject in subjects:
            teacher_name = class_subject.teacher.full_name if class_subject.teacher else "Not assigned"
            subject_list.append({
                'id': class_subject.id,
                'subject_name': class_subject.subject.name,
                'teacher_name': teacher_name,
                'schedule': class_subject.schedule,
            })
        
        return JsonResponse({'subjects': subject_list})
    
    return JsonResponse({'subjects': []})
