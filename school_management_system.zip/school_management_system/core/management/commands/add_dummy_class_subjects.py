from django.core.management.base import BaseCommand
from core.models import Class, Subject, Teacher, ClassSubject

class Command(BaseCommand):
    help = 'Adds dummy ClassSubject data to the database'

    def handle(self, *args, **options):
        self.stdout.write(self.style.SUCCESS('Adding dummy ClassSubject data...'))

        # Get existing classes, subjects, and teachers
        classes = list(Class.objects.all())
        subjects = list(Subject.objects.all())
        teachers = list(Teacher.objects.all())

        if not classes:
            self.stdout.write(self.style.WARNING('No classes found. Please add classes first.'))
            return
        if not subjects:
            self.stdout.write(self.style.WARNING('No subjects found. Please add subjects first.'))
            return
        if not teachers:
            self.stdout.write(self.style.WARNING('No teachers found. Please add teachers first.'))
            return

        # Create some ClassSubject combinations
        class_subject_combinations = [
            (classes[0], subjects[0], teachers[0]), # Class A, BIM, David Lee
            (classes[0], subjects[1], teachers[1]), # Class A, BCA, Emily Clark
            (classes[1], subjects[0], teachers[2]), # Class B, BIM, Frank White
            (classes[1], subjects[2], teachers[0]), # Class B, BBA, David Lee
            (classes[2], subjects[1], teachers[1]), # Class C, BCA, Emily Clark
            (classes[2], subjects[3], teachers[2]), # Class C, BBM, Frank White
        ]

        for class_obj, subject, teacher in class_subject_combinations:
            class_subject, created = ClassSubject.objects.get_or_create(
                class_obj=class_obj,
                subject=subject,
                defaults={
                    'teacher': teacher,
                    'schedule': 'Mon, Wed, Fri 9:00-10:00 AM'
                }
            )
            if created:
                self.stdout.write(self.style.SUCCESS(f'Successfully added ClassSubject: {class_subject}'))
            else:
                self.stdout.write(self.style.WARNING(f'ClassSubject already exists: {class_subject}'))

        self.stdout.write(self.style.SUCCESS('Dummy ClassSubject data added.'))
