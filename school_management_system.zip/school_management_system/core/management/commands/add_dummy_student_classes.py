from django.core.management.base import BaseCommand
from core.models import Student, Class, StudentClass

class Command(BaseCommand):
    help = 'Adds dummy StudentClass data to the database'

    def handle(self, *args, **options):
        self.stdout.write(self.style.SUCCESS('Adding dummy StudentClass data...'))

        # Get existing students and classes
        students = list(Student.objects.all())
        classes = list(Class.objects.all())

        if not students:
            self.stdout.write(self.style.WARNING('No students found. Please add students first.'))
            return
        if not classes:
            self.stdout.write(self.style.WARNING('No classes found. Please add classes first.'))
            return

        # Create some StudentClass combinations
        student_class_combinations = [
            (students[0], classes[0]),  # Alice Smith in Class A
            (students[1], classes[0]),  # Bob Johnson in Class A
            (students[2], classes[1]),  # Charlie Brown in Class B
        ]

        for student, class_obj in student_class_combinations:
            student_class, created = StudentClass.objects.get_or_create(
                student=student,
                class_obj=class_obj,
                defaults={}
            )
            if created:
                self.stdout.write(self.style.SUCCESS(f'Successfully enrolled {student.full_name} in {class_obj.name}'))
            else:
                self.stdout.write(self.style.WARNING(f'{student.full_name} is already enrolled in {class_obj.name}'))

        self.stdout.write(self.style.SUCCESS('Dummy StudentClass data added.'))
