from django.core.management.base import BaseCommand
from core.models import Subject

class Command(BaseCommand):
    help = 'Adds initial subjects to the database'

    def handle(self, *args, **options):
        subjects_to_add = [
            {'name': 'Business Information Management', 'code': 'BIM', 'credits': 3},
            {'name': 'Bachelor of Computer Applications', 'code': 'BCA', 'credits': 4},
            {'name': 'Bachelor of Business Administration', 'code': 'BBA', 'credits': 3},
            {'name': 'Bachelor of Business Management', 'code': 'BBM', 'credits': 3},
        ]

        for subject_data in subjects_to_add:
            subject, created = Subject.objects.get_or_create(
                code=subject_data['code'],
                defaults={
                    'name': subject_data['name'],
                    'credits': subject_data['credits'],
                    'description': f'{subject_data['name']} course',
                }
            )
            if created:
                self.stdout.write(self.style.SUCCESS(f'Successfully added subject: {subject.name}'))
            else:
                self.stdout.write(self.style.WARNING(f'Subject already exists: {subject.name}'))
