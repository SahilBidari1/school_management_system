from django.core.management.base import BaseCommand
from core.models import Teacher
from datetime import date

class Command(BaseCommand):
    help = 'Adds dummy teacher data to the database'

    def handle(self, *args, **options):
        teachers_to_add = [
            {'teacher_id': 'T001', 'first_name': 'David', 'last_name': 'Lee', 'email': 'david.lee@example.com', 'phone': '111-333-5555', 'date_of_birth': date(1980, 3, 20), 'gender': 'M', 'address': '101 Elm St', 'qualification': 'M.Sc. Computer Science', 'experience_years': 10},
            {'teacher_id': 'T002', 'first_name': 'Emily', 'last_name': 'Clark', 'email': 'emily.c@example.com', 'phone': '222-444-6666', 'date_of_birth': date(1975, 7, 10), 'gender': 'F', 'address': '202 Birch Rd', 'qualification': 'Ph.D. Business Admin', 'experience_years': 15},
            {'teacher_id': 'T003', 'first_name': 'Frank', 'last_name': 'White', 'email': 'frank.w@example.com', 'phone': '333-666-9999', 'date_of_birth': date(1988, 11, 5), 'gender': 'M', 'address': '303 Cedar Ave', 'qualification': 'M.Sc. Mathematics', 'experience_years': 7},
        ]

        for teacher_data in teachers_to_add:
            teacher, created = Teacher.objects.get_or_create(
                teacher_id=teacher_data['teacher_id'],
                defaults=teacher_data
            )
            if created:
                self.stdout.write(self.style.SUCCESS(f'Successfully added teacher: {teacher.full_name}'))
            else:
                self.stdout.write(self.style.WARNING(f'Teacher already exists: {teacher.full_name}'))
