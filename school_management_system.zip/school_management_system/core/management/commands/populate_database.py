from django.core.management.base import BaseCommand
from django.core.management import call_command

class Command(BaseCommand):
    help = 'Populates the database with initial data by calling other management commands'

    def handle(self, *args, **options):
        self.stdout.write(self.style.SUCCESS('Starting database population...'))
        
        self.stdout.write(self.style.SUCCESS('Adding subjects...'))
        call_command('add_subjects')

        self.stdout.write(self.style.SUCCESS('Adding classes...'))
        call_command('add_classes')

        self.stdout.write(self.style.SUCCESS('Adding dummy students...'))
        call_command('add_dummy_students')

        self.stdout.write(self.style.SUCCESS('Adding dummy teachers...'))
        call_command('add_dummy_teachers')

        self.stdout.write(self.style.SUCCESS('Database population completed.'))
