from django.core.management.base import BaseCommand
from core.models import Student
from datetime import date

class Command(BaseCommand):
    help = 'Adds dummy student data to the database'

    def handle(self, *args, **options):
        students_to_add = [
            {'student_id': 'S001', 'first_name': 'Alice', 'last_name': 'Smith', 'email': 'alice.smith@example.com', 'phone': '111-222-3333', 'date_of_birth': date(2008, 5, 15), 'gender': 'F', 'address': '123 Oak Ave'},
            {'student_id': 'S002', 'first_name': 'Bob', 'last_name': 'Johnson', 'email': 'bob.j@example.com', 'phone': '444-555-6666', 'date_of_birth': date(2007, 10, 20), 'gender': 'M', 'address': '456 Pine Rd'},
            {'student_id': 'S003', 'first_name': 'Charlie', 'last_name': 'Brown', 'email': 'charlie.b@example.com', 'phone': '777-888-9999', 'date_of_birth': date(2009, 1, 1), 'gender': 'M', 'address': '789 Maple St'},
        ]

        for student_data in students_to_add:
            student, created = Student.objects.get_or_create(
                student_id=student_data['student_id'],
                defaults=student_data
            )
            if created:
                self.stdout.write(self.style.SUCCESS(f'Successfully added student: {student.full_name}'))
            else:
                self.stdout.write(self.style.WARNING(f'Student already exists: {student.full_name}'))
