from django.core.management.base import BaseCommand
from core.models import Class

class Command(BaseCommand):
    help = 'Adds initial classes to the database'

    def handle(self, *args, **options):
        classes_to_add = [
            {'name': 'Class A', 'description': 'Tenth Grade', 'capacity': 40, 'academic_year': '2025-2026'},
            {'name': 'Class B', 'description': 'Eleventh Grade', 'capacity': 35, 'academic_year': '2025-2026'},
            {'name': 'Class C', 'description': 'Twelfth Grade', 'capacity': 30, 'academic_year': '2025-2026'},
        ]

        for class_data in classes_to_add:
            class_obj, created = Class.objects.get_or_create(
                name=class_data['name'],
                academic_year=class_data['academic_year'],
                defaults={
                    'description': class_data['description'],
                    'capacity': class_data['capacity'],
                }
            )
            if created:
                self.stdout.write(self.style.SUCCESS(f'Successfully added class: {class_obj.name}'))
            else:
                self.stdout.write(self.style.WARNING(f'Class already exists: {class_obj.name}'))
