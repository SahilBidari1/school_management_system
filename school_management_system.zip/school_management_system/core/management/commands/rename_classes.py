from django.core.management.base import BaseCommand
from core.models import Class

class Command(BaseCommand):
    help = 'Renames numeric classes to alphabetic names'

    def handle(self, *args, **options):
        rename_mapping = {
            'Class 10': 'Class A',
            'Class 11': 'Class B',
            'Class 12': 'Class C',
        }

        for old_name, new_name in rename_mapping.items():
            try:
                class_obj = Class.objects.get(name=old_name)
                class_obj.name = new_name
                class_obj.save()
                self.stdout.write(self.style.SUCCESS(f'Successfully renamed class from {old_name} to {new_name}'))
            except Class.DoesNotExist:
                self.stdout.write(self.style.WARNING(f'Class {old_name} does not exist. Skipping.'))
            except Exception as e:
                self.stdout.write(self.style.ERROR(f'Error renaming class {old_name}: {e}'))
