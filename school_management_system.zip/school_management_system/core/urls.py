from django.urls import path
from . import views

app_name = 'core'

urlpatterns = [
    # Dashboard
    path('', views.dashboard, name='dashboard'),
    path('register/', views.register, name='register'),
    
    # Student URLs
    path('students/', views.student_list, name='student_list'),
    path('students/create/', views.student_create, name='student_create'),
    path('students/<uuid:student_id>/', views.student_detail, name='student_detail'),
    path('students/<uuid:student_id>/update/', views.student_update, name='student_update'),
    path('students/<uuid:student_id>/delete/', views.student_delete, name='student_delete'),
    
    # Teacher URLs
    path('teachers/', views.teacher_list, name='teacher_list'),
    path('teachers/create/', views.teacher_create, name='teacher_create'),
    path('teachers/<uuid:teacher_id>/', views.teacher_detail, name='teacher_detail'),
    path('teachers/<uuid:teacher_id>/update/', views.teacher_update, name='teacher_update'),
    path('teachers/<uuid:teacher_id>/delete/', views.teacher_delete, name='teacher_delete'),
    path('teachers/<uuid:teacher_id>/assign-subject/', views.teacher_assign_subject, name='teacher_assign_subject'),
    path('teachers/<uuid:teacher_id>/subjects/<uuid:pk>/update/', views.teacher_subject_update, name='teacher_subject_update'),
    path('teachers/<uuid:teacher_id>/subjects/<uuid:pk>/delete/', views.teacher_subject_delete, name='teacher_subject_delete'),
    
    # Class URLs
    path('classes/', views.class_list, name='class_list'),
    path('classes/create/', views.class_create, name='class_create'),
    path('classes/<uuid:class_id>/', views.class_detail, name='class_detail'),
    path('classes/<uuid:pk>/update/', views.class_update, name='class_update'),
    path('classes/<uuid:pk>/delete/', views.class_delete, name='class_delete'),
    path('classes/<uuid:class_id>/enroll-students/', views.enroll_students_in_class, name='enroll_students_in_class'),
    path('classes/<uuid:class_id>/students/<uuid:pk>/update/', views.student_class_update, name='student_class_update'),
    path('classes/<uuid:class_id>/students/<uuid:pk>/delete/', views.student_class_delete, name='student_class_delete'),
    
    # Class Subject URLs
    path('classes/<uuid:class_id>/subjects/add/', views.class_subject_create, name='class_subject_create'),
    path('classes/<uuid:class_id>/subjects/<uuid:pk>/update/', views.class_subject_update, name='class_subject_update'),
    path('classes/<uuid:class_id>/subjects/<uuid:pk>/delete/', views.class_subject_delete, name='class_subject_delete'),
    
    # Attendance URLs
    path('attendance/', views.attendance_list, name='attendance_list'),
    path('attendance/create/', views.attendance_create, name='attendance_create'),
    path('attendance/<uuid:pk>/update/', views.attendance_update, name='attendance_update'),
    path('attendance/statistics/', views.attendance_statistics, name='attendance_statistics'),
    
    # Grade URLs
    path('grades/', views.grade_list, name='grade_list'),
    path('grades/create/', views.grade_create, name='grade_create'),
    
    # API URLs for AJAX
    path('api/students-by-class/', views.get_students_by_class, name='get_students_by_class'),
    path('api/class-subjects/', views.get_class_subjects, name='get_class_subjects'),
]
