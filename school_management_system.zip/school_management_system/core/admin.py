from django.contrib import admin
from .models import Student, Teacher, Class, Subject, ClassSubject, StudentClass, Attendance, Grade

@admin.register(Student)
class StudentAdmin(admin.ModelAdmin):
    list_display = ['student_id', 'first_name', 'last_name', 'email', 'gender', 'enrollment_date', 'is_active']
    list_filter = ['gender', 'enrollment_date', 'is_active']
    search_fields = ['student_id', 'first_name', 'last_name', 'email']
    readonly_fields = ['id', 'enrollment_date']
    fieldsets = (
        ('Basic Information', {
            'fields': ('student_id', 'first_name', 'last_name', 'email', 'phone', 'date_of_birth', 'gender')
        }),
        ('Address & Status', {
            'fields': ('address', 'is_active', 'profile_picture')
        }),
        ('System Information', {
            'fields': ('id', 'enrollment_date', 'user'),
            'classes': ('collapse',)
        }),
    )

@admin.register(Teacher)
class TeacherAdmin(admin.ModelAdmin):
    list_display = ['teacher_id', 'first_name', 'last_name', 'email', 'gender', 'hire_date', 'is_active']
    list_filter = ['gender', 'hire_date', 'is_active', 'experience_years']
    search_fields = ['teacher_id', 'first_name', 'last_name', 'email']
    readonly_fields = ['id', 'hire_date']
    fieldsets = (
        ('Basic Information', {
            'fields': ('teacher_id', 'first_name', 'last_name', 'email', 'phone', 'date_of_birth', 'gender')
        }),
        ('Professional Information', {
            'fields': ('qualification', 'experience_years', 'address', 'is_active', 'profile_picture')
        }),
        ('System Information', {
            'fields': ('id', 'hire_date', 'user'),
            'classes': ('collapse',)
        }),
    )

@admin.register(Class)
class ClassAdmin(admin.ModelAdmin):
    list_display = ['name', 'academic_year', 'capacity', 'is_active', 'created_at']
    list_filter = ['academic_year', 'is_active', 'created_at']
    search_fields = ['name', 'description']
    readonly_fields = ['id', 'created_at']

@admin.register(Subject)
class SubjectAdmin(admin.ModelAdmin):
    list_display = ['name', 'code', 'credits', 'is_active']
    list_filter = ['credits', 'is_active']
    search_fields = ['name', 'code', 'description']
    readonly_fields = ['id']

@admin.register(ClassSubject)
class ClassSubjectAdmin(admin.ModelAdmin):
    list_display = ['class_obj', 'subject', 'teacher', 'schedule']
    list_filter = ['class_obj', 'subject', 'teacher']
    search_fields = ['class_obj__name', 'subject__name', 'teacher__first_name', 'teacher__last_name']
    readonly_fields = ['id']

@admin.register(StudentClass)
class StudentClassAdmin(admin.ModelAdmin):
    list_display = ['student', 'class_obj', 'enrollment_date', 'is_active']
    list_filter = ['class_obj', 'enrollment_date', 'is_active']
    search_fields = ['student__first_name', 'student__last_name', 'class_obj__name']
    readonly_fields = ['id', 'enrollment_date']

@admin.register(Attendance)
class AttendanceAdmin(admin.ModelAdmin):
    list_display = ['student', 'class_subject', 'date', 'status', 'recorded_by']
    list_filter = ['status', 'date', 'class_subject__class_obj', 'class_subject__subject']
    search_fields = ['student__first_name', 'student__last_name', 'class_subject__subject__name']
    readonly_fields = ['id', 'recorded_at']
    date_hierarchy = 'date'

@admin.register(Grade)
class GradeAdmin(admin.ModelAdmin):
    list_display = ['student', 'class_subject', 'assignment_name', 'grade', 'score', 'max_score', 'graded_by']
    list_filter = ['grade', 'class_subject__class_obj', 'class_subject__subject', 'graded_at']
    search_fields = ['student__first_name', 'student__last_name', 'assignment_name', 'class_subject__subject__name']
    readonly_fields = ['id', 'graded_at', 'percentage']
    list_editable = ['grade', 'score']
