from django import forms
from django.contrib.auth.forms import UserCreationForm, UserChangeForm
from django.contrib.auth.models import User
from .models import Class, Student # Import Student model
from .models import Subject, Teacher, ClassSubject # Import for ClassSubjectForm

class CustomUserCreationForm(UserCreationForm):
    class Meta(UserCreationForm.Meta):
        model = User
        fields = UserCreationForm.Meta.fields + ('email',)

class ClassForm(forms.ModelForm):
    class Meta:
        model = Class
        fields = ['name', 'description', 'capacity', 'academic_year']
        widgets = {
            'name': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'e.g., Class A'}),
            'description': forms.Textarea(attrs={'class': 'form-control', 'rows': 3, 'placeholder': 'Brief description of the class'}),
            'capacity': forms.NumberInput(attrs={'class': 'form-control', 'min': 1, 'placeholder': 'e.g., 30'}),
            'academic_year': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'e.g., 2025-2026'}),
        }

class StudentForm(forms.ModelForm):
    class Meta:
        model = Student
        fields = ['student_id', 'first_name', 'last_name', 'email', 'phone', 'date_of_birth', 'gender', 'address', 'profile_picture']
        widgets = {
            'student_id': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'e.g., S001'}),
            'first_name': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'e.g., John'}),
            'last_name': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'e.g., Doe'}),
            'email': forms.EmailInput(attrs={'class': 'form-control', 'placeholder': 'e.g., john.doe@example.com'}),
            'phone': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'e.g., +1234567890'}),
            'date_of_birth': forms.DateInput(attrs={'class': 'form-control', 'type': 'date'}),
            'gender': forms.Select(attrs={'class': 'form-select'}),
            'address': forms.Textarea(attrs={'class': 'form-control', 'rows': 3, 'placeholder': 'Street, City, State, Zip'}),
            'profile_picture': forms.FileInput(attrs={'class': 'form-control'}),
        }

class ClassSubjectForm(forms.ModelForm):
    class Meta:
        model = ClassSubject
        fields = ['subject', 'teacher', 'schedule']
        widgets = {
            'subject': forms.Select(attrs={'class': 'form-select'}),
            'teacher': forms.Select(attrs={'class': 'form-select'}),
            'schedule': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'e.g., Mon, Wed, Fri 9:00-10:00 AM'}),
        }

class AssignSubjectToTeacherForm(forms.ModelForm):
    class Meta(ClassSubjectForm.Meta):
        model = ClassSubject
        fields = ['class_obj', 'subject', 'schedule']
        widgets = {
            'class_obj': forms.Select(attrs={'class': 'form-select'}),
            'subject': forms.Select(attrs={'class': 'form-select'}),
            'schedule': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'e.g., Mon, Wed, Fri 9:00-10:00 AM'}),
        }

class TeacherForm(forms.ModelForm):
    class Meta:
        model = Teacher
        fields = ['teacher_id', 'first_name', 'last_name', 'email', 'phone', 'date_of_birth', 'gender', 'address', 'qualification', 'experience_years', 'profile_picture']
        widgets = {
            'teacher_id': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'e.g., T001'}),
            'first_name': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'e.g., Jane'}),
            'last_name': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'e.g., Doe'}),
            'email': forms.EmailInput(attrs={'class': 'form-control', 'placeholder': 'e.g., jane.doe@example.com'}),
            'phone': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'e.g., +1234567890'}),
            'date_of_birth': forms.DateInput(attrs={'class': 'form-control', 'type': 'date'}),
            'gender': forms.Select(attrs={'class': 'form-select'}),
            'address': forms.Textarea(attrs={'class': 'form-control', 'rows': 3, 'placeholder': 'Street, City, State, Zip'}),
            'qualification': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'e.g., M.Sc. Computer Science'}),
            'experience_years': forms.NumberInput(attrs={'class': 'form-control', 'min': 0, 'placeholder': 'e.g., 5'}),
            'profile_picture': forms.FileInput(attrs={'class': 'form-control'}),
        }