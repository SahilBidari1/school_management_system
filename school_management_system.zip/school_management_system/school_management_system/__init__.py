"""
School Management System Django project package.

Exposes a simple version constant for external introspection.
"""

__all__ = ["__version__"]
__version__ = "0.1.0"


