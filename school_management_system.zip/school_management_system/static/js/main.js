// Main JavaScript file for School Management System

// Global variables
let currentPage = 1;
let isLoading = false;

// Utility Functions
const Utils = {
    // Show loading spinner
    showLoading: function(element) {
        if (element) {
            element.innerHTML = '<div class="text-center"><div class="spinner-border" role="status"><span class="visually-hidden">Loading...</span></div></div>';
        }
    },

    // Hide loading spinner
    hideLoading: function(element, content) {
        if (element && content) {
            element.innerHTML = content;
        }
    },

    // Show notification
    showNotification: function(message, type = 'info') {
        const alertDiv = document.createElement('div');
        alertDiv.className = `alert alert-${type} alert-dismissible fade show`;
        alertDiv.innerHTML = `
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        `;
        
        // Insert at the top of the main content
        const mainContent = document.querySelector('main');
        if (mainContent) {
            mainContent.insertBefore(alertDiv, mainContent.firstChild);
        }
        
        // Auto dismiss after 5 seconds
        setTimeout(() => {
            if (alertDiv.parentNode) {
                alertDiv.remove();
            }
        }, 5000);
    },

    // Format date
    formatDate: function(dateString) {
        const date = new Date(dateString);
        return date.toLocaleDateString('en-US', {
            year: 'numeric',
            month: 'short',
            day: 'numeric'
        });
    },

    // Format currency
    formatCurrency: function(amount) {
        return new Intl.NumberFormat('en-US', {
            style: 'currency',
            currency: 'USD'
        }).format(amount);
    },

    // Debounce function
    debounce: function(func, wait) {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    },

    // Validate email
    isValidEmail: function(email) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    },

    // Validate phone number
    isValidPhone: function(phone) {
        const phoneRegex = /^[\+]?[1-9][\d]{0,15}$/;
        return phoneRegex.test(phone.replace(/[\s\-\(\)]/g, ''));
    }
};

// AJAX Handler
const AjaxHandler = {
    // Make AJAX request
    request: function(url, options = {}) {
        const defaultOptions = {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
                'X-Requested-With': 'XMLHttpRequest'
            }
        };

        const config = { ...defaultOptions, ...options };

        return fetch(url, config)
            .then(response => {
                if (!response.ok) {
                    throw new Error(`HTTP error! status: ${response.status}`);
                }
                return response.json();
            })
            .catch(error => {
                console.error('AJAX Error:', error);
                Utils.showNotification('An error occurred while processing your request.', 'danger');
                throw error;
            });
    },

    // Get students by class
    getStudentsByClass: function(classId) {
        return this.request(`/api/students-by-class/?class_id=${classId}`);
    },

    // Get class subjects
    getClassSubjects: function(classId) {
        return this.request(`/api/class-subjects/?class_id=${classId}`);
    }
};

// Form Handler
const FormHandler = {
    // Initialize form validation
    initValidation: function(formId) {
        const form = document.getElementById(formId);
        if (!form) return;

        form.addEventListener('submit', function(e) {
            if (!FormHandler.validateForm(form)) {
                e.preventDefault();
                return false;
            }
        });

        // Real-time validation
        const inputs = form.querySelectorAll('input, select, textarea');
        inputs.forEach(input => {
            input.addEventListener('blur', function() {
                FormHandler.validateField(this);
            });
        });
    },

    // Validate entire form
    validateForm: function(form) {
        let isValid = true;
        const inputs = form.querySelectorAll('input, select, textarea');
        
        inputs.forEach(input => {
            if (!FormHandler.validateField(input)) {
                isValid = false;
            }
        });

        return isValid;
    },

    // Validate individual field
    validateField: function(field) {
        const value = field.value.trim();
        const type = field.type;
        const name = field.name;
        
        // Clear previous errors
        FormHandler.clearFieldError(field);
        
        // Required field validation
        if (field.hasAttribute('required') && !value) {
            FormHandler.showFieldError(field, 'This field is required.');
            return false;
        }
        
        // Email validation
        if (type === 'email' && value && !Utils.isValidEmail(value)) {
            FormHandler.showFieldError(field, 'Please enter a valid email address.');
            return false;
        }
        
        // Phone validation
        if (name === 'phone' && value && !Utils.isValidPhone(value)) {
            FormHandler.showFieldError(field, 'Please enter a valid phone number.');
            return false;
        }
        
        // Date validation
        if (type === 'date' && value) {
            const date = new Date(value);
            const today = new Date();
            if (date > today) {
                FormHandler.showFieldError(field, 'Date cannot be in the future.');
                return false;
            }
        }
        
        return true;
    },

    // Show field error
    showFieldError: function(field, message) {
        field.classList.add('is-invalid');
        const errorDiv = document.createElement('div');
        errorDiv.className = 'invalid-feedback';
        errorDiv.textContent = message;
        field.parentNode.appendChild(errorDiv);
    },

    // Clear field error
    clearFieldError: function(field) {
        field.classList.remove('is-invalid');
        const errorDiv = field.parentNode.querySelector('.invalid-feedback');
        if (errorDiv) {
            errorDiv.remove();
        }
    }
};

// Table Handler
const TableHandler = {
    // Initialize table functionality
    init: function(tableId) {
        const table = document.getElementById(tableId);
        if (!table) return;

        // Add sorting functionality
        TableHandler.addSorting(table);
        
        // Add search functionality
        TableHandler.addSearch(table);
        
        // Add row selection
        TableHandler.addRowSelection(table);
    },

    // Add sorting to table
    addSorting: function(table) {
        const headers = table.querySelectorAll('th[data-sortable]');
        headers.forEach(header => {
            header.addEventListener('click', function() {
                const column = this.dataset.column;
                const direction = this.dataset.direction === 'asc' ? 'desc' : 'asc';
                
                // Update header
                headers.forEach(h => h.classList.remove('sort-asc', 'sort-desc'));
                this.classList.add(`sort-${direction}`);
                this.dataset.direction = direction;
                
                // Sort table
                TableHandler.sortTable(table, column, direction);
            });
        });
    },

    // Sort table
    sortTable: function(table, column, direction) {
        const tbody = table.querySelector('tbody');
        const rows = Array.from(tbody.querySelectorAll('tr'));
        
        rows.sort((a, b) => {
            const aValue = a.querySelector(`td[data-${column}]`).textContent;
            const bValue = b.querySelector(`td[data-${column}]`).textContent;
            
            if (direction === 'asc') {
                return aValue.localeCompare(bValue);
            } else {
                return bValue.localeCompare(aValue);
            }
        });
        
        // Reorder rows
        rows.forEach(row => tbody.appendChild(row));
    },

    // Add search functionality
    addSearch: function(table) {
        const searchInput = document.querySelector(`input[data-search="${table.id}"]`);
        if (!searchInput) return;

        const debouncedSearch = Utils.debounce(function() {
            TableHandler.filterTable(table, this.value);
        }, 300);

        searchInput.addEventListener('input', debouncedSearch);
    },

    // Filter table
    filterTable: function(table, searchTerm) {
        const rows = table.querySelectorAll('tbody tr');
        const term = searchTerm.toLowerCase();
        
        rows.forEach(row => {
            const text = row.textContent.toLowerCase();
            row.style.display = text.includes(term) ? '' : 'none';
        });
    },

    // Add row selection
    addRowSelection: function(table) {
        const rows = table.querySelectorAll('tbody tr');
        rows.forEach(row => {
            row.addEventListener('click', function() {
                this.classList.toggle('selected');
            });
        });
    }
};

// Search Handler
const SearchHandler = {
    // Initialize search functionality
    init: function() {
        const searchInputs = document.querySelectorAll('.search-input');
        searchInputs.forEach(input => {
            const debouncedSearch = Utils.debounce(function() {
                SearchHandler.performSearch(this.value, this.dataset.target);
            }, 500);

            input.addEventListener('input', debouncedSearch);
        });
    },

    // Perform search
    performSearch: function(query, target) {
        if (!query.trim()) {
            // Show all results
            const items = document.querySelectorAll(target);
            items.forEach(item => item.style.display = '');
            return;
        }

        const items = document.querySelectorAll(target);
        const term = query.toLowerCase();

        items.forEach(item => {
            const text = item.textContent.toLowerCase();
            item.style.display = text.includes(term) ? '' : 'none';
        });
    }
};

// Attendance Handler
const AttendanceHandler = {
    // Initialize attendance form
    init: function() {
        const classSelect = document.getElementById('class_subject');
        if (classSelect) {
            classSelect.addEventListener('change', function() {
                AttendanceHandler.loadStudents(this.value);
            });
        }
    },

    // Load students for attendance
    loadStudents: function(classSubjectId) {
        if (!classSubjectId) return;

        const studentContainer = document.getElementById('student-attendance-list');
        if (!studentContainer) return;

        Utils.showLoading(studentContainer);

        AjaxHandler.getClassSubjects(classSubjectId)
            .then(data => {
                if (data.subjects && data.subjects.length > 0) {
                    const subject = data.subjects[0];
                    return AjaxHandler.getStudentsByClass(subject.class_id);
                }
                throw new Error('No subjects found for this class');
            })
            .then(data => {
                AttendanceHandler.renderStudentList(data.students, studentContainer);
            })
            .catch(error => {
                console.error('Error loading students:', error);
                studentContainer.innerHTML = '<p class="text-muted">No students found for this class.</p>';
            });
    },

    // Render student list for attendance
    renderStudentList: function(students, container) {
        if (!students || students.length === 0) {
            container.innerHTML = '<p class="text-muted">No students enrolled in this class.</p>';
            return;
        }

        const html = students.map(student => `
            <div class="row mb-2 align-items-center">
                <div class="col-md-4">
                    <strong>${student.name}</strong>
                    <br><small class="text-muted">${student.student_id}</small>
                </div>
                <div class="col-md-4">
                    <select class="form-select form-select-sm" name="attendance_${student.id}">
                        <option value="present">Present</option>
                        <option value="absent">Absent</option>
                        <option value="late">Late</option>
                        <option value="excused">Excused</option>
                    </select>
                </div>
                <div class="col-md-4">
                    <input type="text" class="form-control form-control-sm" 
                           name="remarks_${student.id}" placeholder="Remarks (optional)">
                </div>
            </div>
        `).join('');

        container.innerHTML = html;
    }
};

// Grade Handler
const GradeHandler = {
    // Initialize grade form
    init: function() {
        const classSelect = document.getElementById('class_subject');
        if (classSelect) {
            classSelect.addEventListener('change', function() {
                GradeHandler.loadStudents(this.value);
            });
        }
    },

    // Load students for grading
    loadStudents: function(classSubjectId) {
        if (!classSubjectId) return;

        const studentContainer = document.getElementById('student-grade-list');
        if (!studentContainer) return;

        Utils.showLoading(studentContainer);

        AjaxHandler.getClassSubjects(classSubjectId)
            .then(data => {
                if (data.subjects && data.subjects.length > 0) {
                    const subject = data.subjects[0];
                    return AjaxHandler.getStudentsByClass(subject.class_id);
                }
                throw new Error('No subjects found for this class');
            })
            .then(data => {
                GradeHandler.renderStudentList(data.students, studentContainer);
            })
            .catch(error => {
                console.error('Error loading students:', error);
                studentContainer.innerHTML = '<p class="text-muted">No students found for this class.</p>';
            });
    },

    // Render student list for grading
    renderStudentList: function(students, container) {
        if (!students || students.length === 0) {
            container.innerHTML = '<p class="text-muted">No students enrolled in this class.</p>';
            return;
        }

        const html = students.map(student => `
            <div class="row mb-2 align-items-center">
                <div class="col-md-3">
                    <strong>${student.name}</strong>
                    <br><small class="text-muted">${student.student_id}</small>
                </div>
                <div class="col-md-2">
                    <input type="number" class="form-control form-control-sm" 
                           name="score_${student.id}" min="0" max="100" 
                           placeholder="Score" step="0.01">
                </div>
                <div class="col-md-2">
                    <select class="form-select form-select-sm" name="grade_${student.id}">
                        <option value="">Select Grade</option>
                        <option value="A+">A+</option>
                        <option value="A">A</option>
                        <option value="A-">A-</option>
                        <option value="B+">B+</option>
                        <option value="B">B</option>
                        <option value="B-">B-</option>
                        <option value="C+">C+</option>
                        <option value="C">C</option>
                        <option value="C-">C-</option>
                        <option value="D+">D+</option>
                        <option value="D">D</option>
                        <option value="F">F</option>
                    </select>
                </div>
                <div class="col-md-5">
                    <input type="text" class="form-control form-control-sm" 
                           name="remarks_${student.id}" placeholder="Remarks (optional)">
                </div>
            </div>
        `).join('');

        container.innerHTML = html;
    }
};

// Initialize all handlers when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    // Initialize form validation
    FormHandler.initValidation('studentForm');
    FormHandler.initValidation('teacherForm');
    FormHandler.initValidation('attendanceForm');
    FormHandler.initValidation('gradeForm');

    // Initialize table functionality
    TableHandler.init('studentsTable');
    TableHandler.init('teachersTable');
    TableHandler.init('classesTable');

    // Initialize search functionality
    SearchHandler.init();

    // Initialize attendance handler
    AttendanceHandler.init();

    // Initialize grade handler
    GradeHandler.init();

    // Add fade-in animation to cards
    const cards = document.querySelectorAll('.card');
    cards.forEach((card, index) => {
        card.style.animationDelay = `${index * 0.1}s`;
        card.classList.add('fade-in');
    });

    // Auto-hide alerts after 5 seconds
    const alerts = document.querySelectorAll('.alert');
    alerts.forEach(alert => {
        setTimeout(() => {
            if (alert.parentNode) {
                alert.remove();
            }
        }, 5000);
    });

    // Add confirmation for delete actions
    const deleteButtons = document.querySelectorAll('[data-confirm]');
    deleteButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            const message = this.dataset.confirm || 'Are you sure you want to proceed?';
            if (!confirm(message)) {
                e.preventDefault();
                return false;
            }
        });
    });
});

// Export for use in other scripts
window.SchoolManagementSystem = {
    Utils,
    AjaxHandler,
    FormHandler,
    TableHandler,
    SearchHandler,
    AttendanceHandler,
    GradeHandler
};
